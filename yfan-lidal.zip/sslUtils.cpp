//============================================================================
// Name        : TP.cpp
// Author      : Huseyin Kayahan
// Version     : 1.0
// Copyright   : All rights reserved. Do not distribute.
// Description : TP Program
//============================================================================

#include <openssl/evp.h>
#include <openssl/opensslv.h>
#include <openssl/rand.h>
#include <openssl/ssl.h>
#include <openssl/x509_vfy.h>
#include <cstdio>
#include "sslUtils.h"
#include "commonUtils.h"
#include <stdexcept>
#include <iostream>


static unsigned char *Key = new unsigned char[32];
static unsigned char *IV = new unsigned char[16];


BIO *bio_err = 0;
BIO * bio;

int berr_exit(const char *string) {
	BIO_printf(bio_err, "%s\n", string);
	ERR_print_errors(bio_err);
	exit(0);
}

//define the PEM pass phrase for both client and server
static int pswd_cb(char *buf, int num, int rwflag, void *pass_phrase){
	const char *pswd="IK2206";
	strcpy(buf,pswd);
	return(strlen(buf));
}

//=======================Implement the four functions below============================================

SSL *createSslObj(int role, int contChannel, char *certfile, char *keyfile, char *rootCApath ) {
	/* In this function, you handle
	 * 1) The SSL handshake between the server and the client.
	 * 2) Authentication
	 * 		a) Both the server and the client rejects if the presented certificate is not signed by the trusted CA.
	 * 		b) Client rejects if the the server's certificate does not contain a pre-defined string of your choice in the common name (CN) in the subject.
	 */


	SSL *ssl;
	SSL_CTX * ctx;
	SSL_METHOD * meth;

	//initial SSL
	SSL_library_init();
	OpenSSL_add_all_algorithms();
	//initial error message
	SSL_load_error_strings();

	//setup connection method for this session
	if(!role){
		meth =(SSL_METHOD *)SSLv23_server_method();
	}
	else{
		meth =(SSL_METHOD *)SSLv23_client_method();
	}

	//setup ssl environment
	ctx = SSL_CTX_new(meth);
	if(ctx == NULL){

		exit(1);
	}


	//set the default PEM pass phrase
	SSL_CTX_set_default_passwd_cb(ctx,pswd_cb);

	//load certificate
	SSL_CTX_use_certificate_file(ctx, certfile, SSL_FILETYPE_PEM);
	if(!SSL_CTX_use_certificate_file(ctx, certfile, SSL_FILETYPE_PEM)){
		berr_exit("%d \n\n failed download certificate!");

	}

	//load private key
	SSL_CTX_use_PrivateKey_file(ctx,keyfile,SSL_FILETYPE_PEM);
	if(!SSL_CTX_use_PrivateKey_file(ctx,keyfile,SSL_FILETYPE_PEM)){
		berr_exit("%d \n\n failed load key file!");

	}


	//check if the certificate matches with Private key
	SSL_CTX_check_private_key(ctx);
	if(!SSL_CTX_check_private_key(ctx)){
		printf("\n\n Don't Match! \n");
		exit(1);
	}
	//setup session handshake and load CA certificate
	SSL_CTX_load_verify_locations(ctx,rootCApath,NULL);
	if(SSL_CTX_load_verify_locations(ctx, rootCApath, NULL)<0){

		printf("%d \n\n failed download CA certificate!\n", SSL_CTX_load_verify_locations(ctx,rootCApath,NULL));
		exit(-1);

	}
	//define how client and server verify certificates
	if(!role){

		SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER|SSL_VERIFY_FAIL_IF_NO_PEER_CERT, NULL);
	}else

		SSL_CTX_set_verify(ctx,SSL_VERIFY_PEER,NULL);


	/*Authentication*/
	ssl=SSL_new(ctx);
	//setup SSL socket channel for key exchange communication
	bio= BIO_new_socket(contChannel,BIO_NOCLOSE);
	SSL_set_bio(ssl,bio,bio);

	//setup for server and client action to the socket
	char *ComName;
	char peerCN[256];
	int finished = 4;

	if(!role){
		finished =SSL_accept(ssl);
		ComName = "TP Client yfan@kth.se lidal@kth.se";
	}
	else{
		finished =SSL_connect(ssl);
		ComName = "TP Server yfan@kth.se lidal@kth.se";
	}

	if (finished <= 0) {
		printf("%i %i\n", SSL_get_error(ssl,finished),finished);
		berr_exit("SSL connection failed");
	}


	/*check the common name for server and client*/

	X509 *peer;
	char peerCN[256];
	peer =SSL_get_peer_certificate(ssl);
	X509_NAME_get_text_by_NID(X509_get_subject_name(peer), NID_commonName, peerCN,256);
	if(strcasecmp(ComName, peerCN)){
		printf("Common Name dosen't match!");
		berr_exit("Unexpected CommonName");
	}

	printf("SSL tunnel established \n");
	return ssl;
}



void dataChannelKeyExchange(int role, SSL *ssl) {


	/* In this function, you handle
	 * 1) The generation of the key and the IV that is needed to symmetrically encrypt/decrypt the IP datagrams over UDP (data channel).
	 * 2) The exchange of the symmetric key and the IV over the control channel secured by the SSL object.
	 */
	int KeyL=256/8;
	int IVL=128/8;
	if (!role){
		//server generate the key and iv send through ssl
		for (int j=0; j<KeyL; j++){
			Key[j]=(unsigned char)rand();
		}
		SSL_write(ssl,Key,KeyL);

		for (int i=0; i<IVL; i++){
			IV[i]=(unsigned char)rand();
		}
		SSL_write(ssl,IV,IVL);
	}
	else{
		//client receive key and iv from server
		int recv;
		recv = SSL_read(ssl,Key,KeyL);
		//verify
		if(KeyL != recv){
		berr_exit("Key length was wrong");
		}

		recv = SSL_read(ssl,IV,IVL);
		if(IVL != recv){
		berr_exit("IV length was wrong");\
		}

	}


}

int encrypt(unsigned char *plainText, int plainTextLen,
		unsigned char *cipherText) {

	/* In this function, you store the symmetrically encrypted form of the IP datagram at *plainText, into the memory at *cipherText.
	 * The memcpy below directly copies *plainText into *cipherText, therefore the tunnel works unencrypted. It is there for you to
	 * test if the tunnel works initially, so remove that line once you start implementing this function.
	 */
	EVP_CIPHER_CTX *ctx;
	int length;
	int cipherTextLen;

	//create and initialize the context
	if(!(ctx=EVP_CIPHER_CTX_new())){
		ERR_print_errors_fp(stderr);
		exit(0);
	}
	//initialise encryption, check the KEY and IV size
	if(1!=EVP_EncryptInit_ex(ctx,EVP_aes_256_cbc(),NULL,Key,IV)){
		ERR_print_errors_fp(stderr);
		exit(-1);
	}
	
	
	//provide the message to be encrypted, get the output
	if(1!=EVP_EncryptUpdate(ctx,cipherText,&length,plainText,plainTextLen)){
		ERR_print_errors_fp(stderr);
		cipherTextLen=length;

	}

	//finish encryption
	if(1!=EVP_EncryptFinal_ex(ctx,cipherText+length,&length)){
		ERR_print_errors_fp(stderr);
		cipherTextLen += length;
	}

	//clean up
	EVP_CIPHER_CTX_free(ctx);



	return cipherTextLen;

}

int decrypt(unsigned char *cipherText, int cipherTextLen,
		unsigned char *plainText) {
	/* In this function, you symmetrically decrypt the data at *cipherText and store the output IP datagram at *plainText.
	 * The memcpy below directly copies *cipherText into *plainText, therefore the tunnel works unencrypted. It is there for you to
	 * test if the tunnel works initially, so remove that line once you start implementing this function.
	 */


	EVP_CIPHER_CTX *ctx;
	int length;
	int plainTextLen;

	//verify the length of cipherText
	if(cipherTextLen %16 !=0){
		return 0;
	}

	//create and initialise the context
	if(!(ctx=EVP_CIPHER_CTX_new())){
		ERR_print_errors_fp(stderr);
		exit(0);
	}

	//initialise decryption, check the KEY and IV size
	if(1!=EVP_DecryptInit_ex(ctx,EVP_aes_256_cbc(),NULL,Key,IV)){
		ERR_print_errors_fp(stderr);
		exit(-1);
	}

	//provide the message to be decrypted, get the plaintext output
	if(1!=EVP_DecryptUpdate(ctx,plainText,&length,cipherText,cipherTextLen)){

		ERR_print_errors_fp(stderr);
		plainTextLen=length;
	}

	//finish decryption
	if(1!=EVP_DecryptFinal_ex(ctx,plainText+length,&length)){

		ERR_print_errors_fp(stderr);
		plainTextLen += length;
	}

	//clean up
	EVP_CIPHER_CTX_free(ctx);



	return plainTextLen;

}

